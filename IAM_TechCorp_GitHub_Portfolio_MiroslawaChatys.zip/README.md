
# IAM Solution Design – TechCorp Enterprises (Forage Simulation)

This repository presents a complete Identity and Access Management (IAM) solution for TechCorp Enterprises, designed as part of a virtual job simulation provided by Tata Consultancy Services via Forage.

## 📌 Project Overview

**Role:** IAM Developer  
**Platform:** Forage + TCS Simulation  
**Scenario:** TechCorp, a global tech firm with 150,000+ employees, is undergoing a digital transformation. Your job is to assess their IAM readiness and design tailored IAM solutions.

## ✅ Deliverables

- 🚀 IAM Solution: User lifecycle automation + role-based access control  
- 📄 Final PDF: [IAM_Solution_Design_TechCorp_MiroslawaChatys.pdf](documents/IAM_Solution_Design_TechCorp_MiroslawaChatys.pdf)  
- 🔍 Short version summary: [Example Case Summary](documents/IAM_Solution_Example_Short_TechCorp_MiroslawaChatys.pdf)

## 🛠 Technologies Used

- Azure Active Directory (Conditional Access, MFA)
- Okta Universal Directory
- Power Automate
- SCIM protocol
- Microsoft Defender for Identity

## 🎯 Business Value

- Enhanced onboarding/offboarding speed and security  
- RBAC aligned with business roles and departments  
- Full auditability and reduced insider threat surface  
- Scalable architecture supporting global operations

## 📎 Case Study Summary

The full solution demonstrates how IAM can align with business processes to streamline operations, reduce human error, and reinforce compliance in a cloud-driven environment.

---

Created by **Miroslawa Chatys** as part of the TCS Forage Cybersecurity Simulation.
